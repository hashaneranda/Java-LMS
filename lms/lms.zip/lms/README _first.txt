**create a database called javalms in localhost/phpmyadmin

**Then import javalms.sql file to that database

**Done.